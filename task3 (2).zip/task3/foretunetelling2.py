import sys
import os
import FinanceDataReader as fdr
import openai

# 원하는 site-packages 경로 추가
#sys.path.append('c:\\python\\py_crnt\\3.10\\lib\\site-packages')
#os.chdir(r'C:\Users\Administrator\PycharmProjects\pf_bunyangga')


my_api_key = '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' #신용카드 바꿀것
openai.api_key = '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' #신용카드 바꿀것

df_krx = fdr.StockListing('KRX')


### 기업명detect######



def chatfunc(prompt):
    model_engine = "gpt-4-0125-preview"
    # 맥스 토큰
    # max_tokens = 2048
    messages = [{"role": "system", "content": "You are a helpful assistant."}
        , {"role": "user", "content": prompt}]

    chat = openai.ChatCompletion.create(
        model=model_engine,
        messages=messages,
        temperature=0.2
    )

    reply = chat.choices[0].message.content
    usage = chat.usage

    return (reply, usage)





birth_df = df.copy()

birth_df = pd.DataFrame((birth_df >>
                         filter_(~is_na(f.생년월일)) >>
                         filter_(f.생년월일 != "") >>
                         filter_(~f.생년월일.str.contains('00'))

                         )).reset_index(drop = True)


birth_df['saju'] = None



for i in range(0, len(birth_df)):

    birthday = birth_df.iloc[i]['생년월일']
    firmname = birth_df.iloc[i]['회사명']
    firmcode = birth_df.iloc[i]['종목코드']

    prompt = \
            fr'''
            아래 날짜에 태어난 남자인, 기업 대표이사의 사주팔자에 기반하여 2024년 3월의 사업운과 100점 만점 스코어를 알려줘.\\
            생년월일: {birthday}
            
            다른 설명은 절대 하지마. 오직 사주풀이와 스코어만 json형식으로 알려줘 \
            예컨대 {{"사주풀이":"사업운이 나쁘다", "스코어":"23"}}
            그리고 모르겠는것에 대해서는 절대 답하지마.
            '''

    reply, usage = chatfunc(prompt)

    birth_df.iloc[i, birth_df.columns.get_loc('saju')] = reply
    print([i,birth_df.iloc[i]['saju']])










birth_df >> select(f.생년월일) >> mutate(생년월일 = f.생년월일.replace("/", "."))



birth_df['생년월일2'] = birth_df['생년월일'].str.replace("/", ".")


bbb = birth_df[['생년월일2']]
bbb.to_csv("생년월일.csv", index = False, encoding = "utf-8-sig")

def extract_firmname(data, text_type, rm_words, name_map):
    data =data.with_columns(col("most_firm_title").cast(pl.List(str)).alias("most_firm_title"))
    news_today_comnam_yday_pl = data.filter(col('type') == "yesterday").with_columns(col("most_firm_title").cast(pl.List(str)).alias("most_firm_title"))
    news_today_comnam_tday_pl = data.filter(col('type') == "today").with_columns(col("most_firm_title").cast(pl.List(str)).alias("most_firm_title"))

    news_title = news_today_comnam_tday_pl.select('title').to_series()
    news_today_comnam_tday_pd = news_today_comnam_tday_pl.to_pandas()

    prompt = fr'''
                Ignore all the previous instructions.\n

                Instruction: \n
                1) Find all the company name in the following korean economic news title and put them into []. The list name is "company_name_title".  \n
                2) The example of output format is this: company_name_title = ['CJ CGV', '하인크코리아', '위더스제약']. This is just "EXAMPLE".\n         
                4) The example of output format in case there is no company name in the news title is this: company_name_title = [].\n 
                5) "Just" give me the outputs without any explanation or reference.\n\n

                Warnings:\n
                Never list human name (for example, "윤창현", "임창정" ,"이복현" ,"김동관", "윤석렬", etc) as company name.\n
                Never list global stock market name (for example "KOSDAQ", "코스닥", "KONEX", "코넥스", "KOSPI","코스피", "유가증권", "NASDAQ","나스닥", etc.).\n
                Never list industry name (for example "금융업" ,"Financial Industry","엔터산업","Entertainment Industry", "건축업", "항공업" etc.). \n
                Never list words like "ETF","IPO",'사모펀드',"거래소","기업", "바이오", "의료기기", "철수", "중소기업", "상장사", "건설사", "은행" , "은행채", "회사채".\n\n

                Korean economic news title: 
                '''

    for i in range(len(news_title)):

        max_attempts = 5
        attempt = 0

        while attempt < max_attempts:
            try:
                text_within_brackets = re.match(r'^\[(.*?)\]', news_title[i])
                if text_within_brackets:
                    modified = re.sub(r'^\[(.*?)\]', '', news_title[i]).lstrip()
                else:
                    modified = news_title[i]

                prompt_all = prompt + f'{modified}'

                reply, usage = chatfunc(prompt_all)
                reply = re.sub(r'\\n', r'\n', reply)
                time.sleep(1)

                names0 = re.split(r'\n', reply)[0]
                names = re.search('\[(.*?)\]', names0)[0]
                names = eval(names)

                names = [name_map.get(item.replace(' ', '')\
                                      .replace('(주)', '')\
                                      .replace('㈜', '')\
                                      .replace('서정진', '') \
                                      .replace('서정진', '') \
                                      .replace('證', '증권')\
                                      .replace('銀', '은행')\
                                      .replace('미래', '미래에셋증권')\
                                      .replace('미래에셋', '미래에셋증권')\
                                      .replace('키움', '키움증권')\
                                      .replace('한국', '한국투자증권')\
                                      .lower()
                                      ,item.replace(' ', '')\
                                      .replace('(주)', '')\
                                      .replace('㈜', '')\
                                      .replace('서정진', '') \
                                      .replace('서정진', '') \
                                      .replace('證', '증권')\
                                      .replace('銀', '은행')\
                                      .replace('미래', '미래에셋증권')\
                                      .replace('미래에셋', '미래에셋증권')\
                                      .replace('키움', '키움증권')\
                                      .replace('한국', '한국투자증권')\
                                      .lower()) if item is not None else None for item in names]


                if len(names) > 0:
                    #기업명이 아닌 단어리스트 (경기도, 사모펀드, 한국거래소...)
                    #~업계는 기업명 아님
                    #한투 외 증권사도 기업에서 제외
                    for k in range(len(names)):
                        if names[k] is None:
                            names[k] = ''
                        if (names[k] in rm_words) or ("업계" in names[k]) or ("협회" in names[k]):
                            names[k] = ''
                        if ("증권" in names[k]) and (names[k] not in ["한국투자증권", "한투증권"]):
                            names[k] = ''



                for idx, name in enumerate(names):  # enumerate로 현재 인덱스와 해당 이름 get.
                    words_pos0 = komoran.get_plain_text(name).split(' ')
                    tag_list = [word_tag.split('/')[-1] for word_tag in words_pos0]
                    #print([idx, words_pos0, tag_list])

                    if (tag_list == ['XPN', 'NNG'] and len(name) <= 4) or (
                            tag_list == ['NNG', 'XSN'] and len(name) <= 4) or (
                            tag_list == ['NNG'] and len(name) <= 4):
                        name = ''

                    names[idx] = name_map.get(name, name)

                #print(names)

                first_name = next((name for name in names if name not in [None, '']), '')
                sorted_names = sorted(names)

                news_today_comnam_tday_pd.at[i, f"first_firm_{text_type}"] = first_name
                news_today_comnam_tday_pd.at[i, f"most_firm_{text_type}"] = sorted_names

                break
            except:
                traceback.print_exc()
                attempt += 1
                time.sleep(75)
                # continue
        else:
            # If all attempts fail, execute this block
            print("All attempts failed. Continuing without raising an exception.")
            first_name = ''
            sorted_names = ''
            news_today_comnam_tday_pd.at[i, f"first_firm_{text_type}"] = first_name
            news_today_comnam_tday_pd.at[i, f"most_firm_{text_type}"] = sorted_names

        print(i)
        print(news_today_comnam_tday_pd.at[i, f"first_firm_{text_type}"])
        print(news_today_comnam_tday_pd.at[i, f"most_firm_{text_type}"])

    news_today_comnam_tday_pl = from_pandas(news_today_comnam_tday_pd)
    news_today_comnam_yday_pl = news_today_comnam_yday_pl
    data = news_today_comnam_yday_pl.with_columns(col("most_firm_title").cast(pl.List(str)))\
        .vstack(news_today_comnam_tday_pl.with_columns(col("most_firm_title").cast(pl.List(str))))\
        .with_columns(pl.col("most_firm_title").apply(lambda x: [item for item in x if item != '']))

    return data