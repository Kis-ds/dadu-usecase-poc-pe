import pandas as pd
from datetime import datetime
from datetime import datetime, timedelta, date
from polars import col, when, from_pandas, concat, count
from tqdm import tqdm
import os
import requests
import re
import urllib.parse
import json
import html




from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.service import Service
from selenium.common.exceptions import NoSuchElementException

#from webdriver_manager.chrome import ChromeDriverManager
#driver = webdriver.Chrome(ChromeDriverManager().install())

from urllib.parse import urlparse, parse_qs
import requests

import collections

if not hasattr(collections, 'Callable'):
    collections.Callable = collections.abc.Callable

from bs4 import BeautifulSoup
from html_table_parser import parser_functions as parser

import json
import logging


import time
import pandas as pd
from bs4 import BeautifulSoup
from tqdm import tqdm
import os
import requests
from datetime import date, timedelta
import random
import numpy as np
# from datar.all import *
import re
from re import sub
import xlwings as xw

import FinanceDataReader as fdr



chrome_driver_path = r'C:\Users\Administrator\PycharmProjects\datasolution_news_3_8\pbproject\chromedriver-win64\chromedriver-win64\chromedriver.exe'
service = Service(executable_path=chrome_driver_path)



from bs4 import BeautifulSoup

# Excel 파일 열기
wb = xw.Book(r'C:\Users\Administrator\Downloads\firms.xlsx')

# 첫 번째 시트 선택
sht = wb.sheets[0]

# 사용된 범위 내의 모든 데이터를 가져오기
data = sht.used_range.value
data1 = data[1:len(data)]

firm_data = pd.DataFrame(data1)
firm_data.columns = ["회사명", "종목코드", "업종", "주요제품", "상장일", "결산월", "대표자명", "홈페이지", "지역"]


driver = webdriver.Chrome(service=service)

df = pd.DataFrame()


import FinanceDataReader as fdr
all_stock = fdr.StockListing('KRX').query('(Market == "KOSPI") | (Market == "KOSDAQ")')

alltime_price = fdr.DataReader(all_stock_code, start_dt_krx_str, current_dt_krx_str)


firm_data_new = firm_data >> mutate(Code = f.종목코드)
all_stock_kospi = all_stock >> filter_(f.MarketId == "STK")

우선주 = pd.DataFrame(all_stock_kospi >> anti_join(firm_data_new))


for i in range(len(firm_data)):
    stockcd = firm_data.iloc[i]['종목코드']
    회사명 = firm_data.iloc[i]['회사명']

    url = f"https://comp.kisline.com/co/CO0100M010GE.nice?stockcd={stockcd}&nav=2"
    driver.get(url)

    random_sleep_time = random.uniform(0.5, 3)
    time.sleep(random_sleep_time)

    try:
        div_tbl_inmul = driver.find_element(By.CLASS_NAME, 'tbl.inmul')
        html_content = div_tbl_inmul.get_attribute('outerHTML')

        soup = BeautifulSoup(html_content, 'html.parser')

        # 정보 추출
        info = {}
        info_elements = soup.find('div', class_='tbl inmul').find_all(['th', 'td'])

        # 1번째 엘리먼트부터의 정보 가져오기
        for i in range(1, len(info_elements), 2):
            key = info_elements[i].get_text(strip=True)
            value = info_elements[i + 1].get_text(strip=True)
            info[key] = value

        # DataFrame 생성
        df0 = pd.DataFrame([info])
        df0['종목코드'] = stockcd
        df0['회사명'] = 회사명

        print(df0)

        df = pd.concat([df, df0], axis=0)

        print(df)

    except NoSuchElementException:
        print(f"No table found for 종목코드: {stockcd}")
        continue



df.to_csv("ceoinfo.csv", index = False, encoding = 'utf-8-sig')
df.to_pickle('ceoinfo.pkl')



























for i in range(len(firm_data)):
    stockcd = firm_data.iloc[i]['종목코드']
    회사명 = firm_data.iloc[i]['회사명']

    url = f"https://comp.kisline.com/co/CO0100M010GE.nice?stockcd={stockcd}&nav=2"
    driver.get(url)

    random_sleep_time = random.uniform(0.5, 2)
    time.sleep(random_sleep_time)

    div_tbl_inmul = driver.find_element(By.CLASS_NAME, 'tbl.inmul')
    html_content = div_tbl_inmul.get_attribute('outerHTML')

    soup = BeautifulSoup(html_content, 'html.parser')

    # 정보 추출
    info = {}
    info_elements = soup.find('div', class_='tbl inmul').find_all(['th', 'td'])

    # 1번째 엘리먼트부터의 정보 가져오기
    for i in range(1, len(info_elements), 2):
        key = info_elements[i].get_text(strip=True)
        value = info_elements[i + 1].get_text(strip=True)
        info[key] = value

    # DataFrame 생성
    df0 = pd.DataFrame([info])
    df0['종목코드'] = stockcd
    df0['회사명'] = 회사명

    print(df0)

    df = pd.concat([df,df0], axis = 0)



# BeautifulSoup을 사용하여 HTML 파싱
soup = BeautifulSoup(html_content, 'html.parser')


# BeautifulSoup을 사용하여 HTML 파싱
soup = BeautifulSoup(html_content, 'html.parser')


try:
    # 해당 클래스를 가진 div 요소 찾기
    div_tbl_inmul = driver.find_element(By.CLASS_NAME, 'tbl.inmul')

    # 해당 div 요소 내의 HTML 가져오기
    html_content = div_tbl_inmul.get_attribute('outerHTML')

    # BeautifulSoup을 사용하여 HTML 파싱
    soup = BeautifulSoup(html_content, 'html.parser')

    # 해당 div 요소 내의 모든 텍스트 정보 가져오기
    text_info = soup.get_text(strip=True)

    print(text_info)

except Exception as e:
    print("Error:", e)





response = requests.get(url)
response.raise_for_status()  # 요청 실패 시 예외 발생

soup = BeautifulSoup(html_content, 'html.parser')

# 정보 추출
info = {}
info_elements = soup.find('div', class_='tbl inmul').find_all(['th', 'td'])
for i in range(0, len(info_elements), 2):
    key = info_elements[i].get_text(strip=True)
    value = info_elements[i + 1].get_text(strip=True)
    info[key] = value

# DataFrame 생성
df = pd.DataFrame([info])





# 성명, 직위, 대표번호, 대학원 이상 정보 추출
data = {
    '항목': ['성명', '직위', '대표번호', '대학원 이상'],
    '정보': [soup.find('th', text='성명').find_next_sibling('td').get_text(strip=True),
           soup.find('th', text='직위').find_next_sibling('td').get_text(strip=True),
           soup.find('th', text='대표번호').find_next_sibling('td').get_text(strip=True),
           soup.find('th', text='대학원 이상').find_next_sibling('td').get_text(strip=True)]
}




text_info = soup.get_text(strip=True)







driver.switch_to.frame('frame_id_or_name')

try:
    # 'div.tbl.inmul' 클래스를 가진 div 내부의 모든 table 찾기
    tables = driver.find_elements(By.CSS_SELECTOR, 'div.tbl.inmul table')
    data_found = False


    for table in tables:
        # 각 테이블의 caption 확인
        caption = table.find_element(By.TAG_NAME, 'caption').text
        if caption == '대표자 정보':
            rows = table.find_elements(By.TAG_NAME, 'tr')
            data = []
            for row in rows:
                cols = row.find_elements(By.TAG_NAME, 'th') + row.find_elements(By.TAG_NAME, 'td')
                row_data = [col.text for col in cols]
                data.append(row_data)

            # 데이터를 DataFrame으로 변환
            df = pd.DataFrame(data)
            print(df)
            data_found = True
            break

    if not data_found:
        print("대표자 정보 테이블을 찾을 수 없습니다.")

except NoSuchElementException:
    print("페이지에 'div.tbl.inmul' 클래스 또는 기대하는 요소가 없습니다.")
finally:
    driver.quit()


try:
    # '대표자 정보' 테이블 찾기
    table = driver.find_element(By.CSS_SELECTOR, 'div.tbl.inmul table[caption="대표자 정보"]')

    # 테이블의 모든 행을 찾음
    rows = table.find_elements(By.TAG_NAME, 'tr')

    # 데이터를 저장할 리스트 초기화
    data = []

    # 행과 셀의 데이터 추출
    for row in rows:
        cols = row.find_elements(By.TAG_NAME, 'th') + row.find_elements(By.TAG_NAME, 'td')
        row_data = [col.text for col in cols]
        data.append(row_data)

    # DataFrame으로 변환
    df = pd.DataFrame(data[1:], columns=data[0])
    print(df)

except NoSuchElementException:
    print("대표자 정보 테이블을 찾을 수 없습니다.")
finally:
    driver.quit()









# "tbl inmul" 클래스를 가진 div 내부의 정보 추출
tables = driver.find_elements(By.CSS_SELECTOR, 'div.tbl.inmul table')

for table in tables:
    # '대표자 정보' 캡션을 가진 테이블만 처리
    if table.find_element(By.CSS_SELECTOR, 'caption').text == '대표자 정보':
        rows = table.find_elements(By.CSS_SELECTOR, 'tbody tr')
        for row in rows:
            cells = row.find_elements(By.CSS_SELECTOR, 'th, td')
            for cell in cells:
                print(cell.text, end=' | ')
            print()  # 각 행마다 줄바꿈
        break  # '대표자 정보' 테이블을 찾으면 반복 종료


    indcodes = []
    inds = []
    no_value = '99999'
    ind = '없음'
    a_tags = driver.find_elements(By.XPATH, "//a[contains(@href, '/sise/sise_group_detail.naver?type=upjong&no=')]")

    for a_tag in a_tags:
        href = a_tag.get_attribute('href')
        parsed_href = urlparse(href)
        query_params = parse_qs(parsed_href.query)
        indcode = query_params['no'][0]
        ind = a_tag.text
        indcodes.append(indcode)
        inds.append(ind)
        print([indcode, ind])

    df = pd.DataFrame({'indcodes': indcodes, 'inds': inds})





































soup = BeautifulSoup(response.text, 'html.parser')

# CSS 선택자를 사용하여 특정 요소 선택
selected_section = soup.select_one('#contents > section:nth-child(12)')


# `class`를 이용하여 정보 추출
section = soup.find('section', class_='con')
table = section.find('table') if section else None

# 데이터 추출 및 출력
if table:
    data = []
    for row in table.find_all('tr'):
        cols = row.find_all(['th', 'td'])
        cols_text = [ele.text.strip() for ele in cols]
        data.append(cols_text)

    # 추출된 데이터 출력
    for row in data:
        print(row)
else:
    print("Table not found")


def fetch_ceo_info(stockcd):
    try:
        stockcd = '066970'
        url = f"https://comp.kisline.com/co/CO0100M010GE.nice?stockcd={stockcd}&nav=2"
        response = requests.get(url)
        response.raise_for_status()  # 요청 실패 시 예외 발생

        soup = BeautifulSoup(response.text, 'html.parser')
        table = soup.find('table', {'caption': '대표자 정보'})
        // *[ @ id = "contents"] / section[10]
        if not table:
            print(f"No '대표자 정보' table found for stockcd {stockcd}")
            return None

        rows = table.find_all('tr')
        data = []
        for row in rows:
            cols = row.find_all(['th', 'td'])
            cols = [ele.text.strip() for ele in cols]
            data.append(cols)

        df = pd.DataFrame(data)
        return df
    except requests.RequestException as e:
        print(f"Request error for stockcd {stockcd}: {e}")
    except Exception as e:
        print(f"An error occurred for stockcd {stockcd}: {e}")

stockcd_list = ['475150', '123456', '654321']

for i in range(len(firm_data)):

    stockcd = firm_data.iloc[i]



    try:
        url = f"https://comp.kisline.com/co/CO0100M010GE.nice?stockcd={stockcd}&nav=2"
        response = requests.get(url)
        response.raise_for_status()  # 요청 실패 시 예외 발생

        soup = BeautifulSoup(response.text, 'html.parser')
        table = soup.find('table', {'caption': '대표자 정보'})

        rows = table.find_all('tr')
        data = []
        for row in rows:
            cols = row.find_all(['th', 'td'])
            cols = [ele.text.strip() for ele in cols]
            data.append(cols)

         df = pd.DataFrame(data)

    except requests.RequestException as e:

        print(f"Request error for stockcd {stockcd}: {e}")
    except Exception as e:
        print(f"An error occurred for stockcd {stockcd}: {e}")




    df = fetch_ceo_info(stockcd)


    if df is not None:
        print(f"Data for stockcd {stockcd}:\n", df)
    else:
        print(f"No data found for stockcd {stockcd}. Moving to next.")


for i in range(len(firm_data)):
    stockcd = firm_data.iloc[i]['종목코드']

    url = f"https://comp.kisline.com/co/CO0100M010GE.nice?stockcd={stockcd}&nav=2"
    response = requests.get(url)
    if response.status_code != 200:
        print(f"Error fetching {stockcd}: Status code {response.status_code}")
        None

    soup = BeautifulSoup(response.text, 'html.parser')
    table = soup.find('table', {'caption': '대표자 정보'})

    if not table:
        print(f"No '대표자 정보' table found for stockcd {stockcd}")
        return None

# 대표자 정보를 추출하는 함수
def fetch_ceo_info(stockcd):
    url = f"https://comp.kisline.com/co/CO0100M010GE.nice?stockcd={stockcd}&nav=2"
    response = requests.get(url)
    if response.status_code != 200:
        print(f"Error fetching {stockcd}: Status code {response.status_code}")
        return None

    soup = BeautifulSoup(response.text, 'html.parser')
    table = soup.find('table', {'caption': '대표자 정보'})

    if not table:
        print(f"No '대표자 정보' table found for stockcd {stockcd}")
        return None

    rows = table.find_all('tr')
    data = []
    for row in rows:
        cols = row.find_all(['th', 'td'])
        cols = [ele.text.strip() for ele in cols]
        data.append(cols)

    df = pd.DataFrame(data)
    return df

# stockcd 목록 예시
stockcd_list = ['475150', '123456', '654321']

# 각 stockcd에 대해 대표자 정보 추출
for stockcd in stockcd_list:
    df = fetch_ceo_info(stockcd)
    if df is not None:
        print(f"Data for stockcd {stockcd}:\n", df)
        # 이 부분에서 데이터를 파일로 저장하거나 다른 처리를 할 수 있습니다.
        # 예: df.to_csv(f"{stockcd}_ceo_info.csv", index=False)
    else:
        print(f"No data found for stockcd {stockcd}. Moving to next.")